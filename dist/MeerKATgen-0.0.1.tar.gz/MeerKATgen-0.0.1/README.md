# MeerKATgen
MeerKAT radio telescope simulation package. Designed with performance in mind and utilizes 
Just in time compile (JIT) and XLA backed vectroization for batched functions. Designed for 
geometric inference models for multibeam telescopes. 

** currently under construction ** 
